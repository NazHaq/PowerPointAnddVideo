package utilities;
public class Constant {
public static String URL= "https://tp.transportnsw.info"; 
public static String searchFrom= "name_origin"; 
public static String searchTo= "name_destination"; 
public static String goButton= "mdv_journeySubmit"; 
public static String pageTitle= "Plan your trip using public transport in Sydney and NSW"; 
public static String selectFromLiveSuggestion= ".//*[@id='mdv_locs']/li[text() = 'North Sydney Station, North Sydney']";
public static String selectToLiveSuggestion= ".//*[@id='mdv_locs']/li[text() = 'Town Hall Station, Sydney']"; 
public static String resultSection= "outerboxMonitor"; 

}